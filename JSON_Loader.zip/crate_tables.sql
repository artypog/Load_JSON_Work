create table  IF NOT EXISTS ga_sessions(
	session_id  varchar(120),
	client_id   varchar(60),
	visit_date  date,
	visit_time  time,
	visit_number  int,
	utm_source  varchar(60),
	utm_medium  varchar(60),
	utm_campaign  varchar(60),
	utm_adcontent  varchar(60),
	utm_keyword  varchar(60),
	device_category  varchar(60),
	device_os  varchar(60),
	device_brand   varchar(60),
	device_model  varchar(60),
	device_screen_resolution   varchar(60),
	device_browser  varchar(60),
	geo_country  varchar(60),
	geo_city  varchar(60)
);


create table  IF NOT EXISTS ga_hits(
	session_id varchar(120),
	hit_date date,
	hit_time integer,
	hit_number integer,
	hit_type varchar(60),
	hit_referer varchar(60),
	hit_page_path varchar,
	event_category varchar(60),
	event_action varchar(60),
	event_label varchar(60),
	event_value varchar(60)
);
