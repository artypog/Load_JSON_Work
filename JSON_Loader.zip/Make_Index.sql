ALTER TABLE ga_sessions  ADD PRIMARY KEY (client_id, visit_number);
CREATE INDEX cl_visit_num_idx ON ga_sessions (client_id, visit_number);
CREATE INDEX client_id_idx ON ga_sessions (client_id);
CREATE INDEX sess_id_idx ON ga_hits (session_id);

