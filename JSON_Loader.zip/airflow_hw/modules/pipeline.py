import os
import glob
import psycopg2
import psycopg2.extensions
import shutil
import json
import time
from loguru import logger
from sklearn.pipeline import Pipeline
from dotenv import load_dotenv


# Укажем путь к файлам проекта:
path = os.path.expanduser('~/airflow_hw')

connection : psycopg2.extensions.connection
logger.add(path + "/log/test.log", format="{time} {level} {message}")

def openbase():
    try:
        # пытаемся подключиться к базе данных
        load_dotenv()
        dbname = os.environ.get('dbname')
        user = os.environ.get('user')
        password = os.environ.get('password')
        host = os.environ.get('host')
        # пытаемся подключиться к базе данных
        conn = psycopg2.connect(dbname=dbname, user=user, password=password, host=host)
        logger.info('Соединение с базой данных успешно установлено!\n')
    except:
        # в случае сбоя подключения будет выведено сообщение в STDOUT
        logger.error('Ошибка соединения с базой данных!\n')
        exit()
    return conn


def closebase(connection, cursor):
    if connection:
        cursor.close()
        connection.close()
        print("PostgreSQL соединение с базой dbtest завершено!")

def preparefile(filename):
    tmpfilename = filename + '.tmp'
    f = open(filename, 'r')
    g = open(tmpfilename, 'w')
    for item in f:
        s = item.replace('NaN', "\"null\"")
        s = s.replace(': nan,', ": \"null\",")
        s = s.replace('(none)', "\"null\"")
        s = s.replace("\"\"null\"\"", "\"null\"")
        # print(s[:300])
        # if len(s) > 300:
        #     exit()
        g.write(s)
    f.close()
    g.close()
    time.sleep(3)
    os.remove(filename)
    time.sleep(3)
    os.rename(tmpfilename, filename)
    time.sleep(3)


def JSON2Base(filename, tablename, cursor, connection):
    preparefile(filename)
    with open(filename, 'r') as file:
        cur_session = json.load(file)
    for key in cur_session.keys():
        logger.info(f'Обрабатываем дату {key}')
        i = 0
        for el in cur_session[key]:
            #                logger.info(f'Обрабатываем {el}')
            #                logger.info('-'*72)
            try:
                #Вычисляем список столбцов
                listkey = ' ('
                listval = ' VALUES('
                for elrec in el.keys():
                    listkey = listkey + elrec + ","
                    stemp = str(el[elrec])
                    if stemp is None:
                        stemp = 'null'
                    stemp = stemp.replace("None", "other")
                    stemp = stemp.replace(": null,", ": \"null\",")
                    stemp = stemp.replace(": null}", ": \"null\"}")
                    stemp = stemp.replace("(none)", "other")
                    stemp = stemp.replace("'", "")
                    stemp = stemp.replace(": NaN", ": \"null\"")
                    listval = listval + "'" + str(stemp) + "'" + ','
                listkey = listkey       [:-1] + ')'
                listval = listval[:-1] + ')'
                s = "INSERT INTO " + tablename + listkey + listval
                s = str(s)
                try:
                    cursor.execute(s)
                except:
                    logger.error(f'Ошибка добавления записи в таблицу ga_sessions (синтаксис)')
                    logger.error(f'SQl - код {s}')
                if i == 1000:
                    connection.commit()
                    i = 0
                i += 1
        #                    logger.info('Успешно добавлена одна запись в ga_sessions')
            except:
                logger.error(f'Ошибка добавления записи в таблицу ga_sessions')
                logger.info(f'Обрабатывался {el}')
    connection.commit()


def load_sessions(cursor, connection):
    for name in sorted(glob.glob(path+'/data/jsons/ga_sessions_new_*.json')):
        logger.info(f'Обрабатываю файл {name}')
        JSON2Base(name, 'GA_SESSIONS', cursor, connection)
        # Вычисляем путь к архивным json
        pos = name.index('ga_sessions_new')
        arch_path=name[:pos] + 'arch'
        move_file_to_arch(name, arch_path)



def load_hits(cursor, connection):
    for name in sorted(glob.glob(path+'/data/jsons/ga_hits_new_*.json')):
        logger.info(f'Обрабатываю файл {name}')
        JSON2Base(name, 'GA_HITS', cursor, connection)
        # Вычисляем путь к архивным json
        pos = name.index('ga_hits_new')
        arch_path = name[:pos] + 'arch'
        move_file_to_arch(name, arch_path)


def move_file_to_arch(name, arch_path):
    try:
        # пытаемся перенести файл по архивному пути
        shutil.move(name, arch_path)
        logger.info(f'Файл {name} успешно перенесен в архив!')
    # После обработки перемещаем файл в архив
    except:
        logger.error(f'Ошибка перемещения в архивный каталог файла {name}\n')


def pipeline() -> None:

#Подключаемся в базе данных
    connection = openbase()
    cursor = connection.cursor()
#Загружаем сессии
    load_sessions(cursor, connection)

# Теперь обрабатываем добавление записей в ga_hits_new
    load_hits(cursor, connection)

    closebase(connection, cursor)


def copyJSON2Base():
    preprocessor = Pipeline(steps=[
        ('pipeline', pipeline())
    ])


if __name__ == '__main__':
    copyJSON2Base()

